*====================================================================*
*  INCLUDE: ZREFI_FE_COMPLEMENTO_LOGICA_V4  (CORREGIDO)
*  - f_verificar: muestra ALV y vuelve a parámetros en Back/Exit
*  - no emitir aquí; la emisión se hace desde botón EMIT del ALV
*====================================================================*

FORM f_verificar .

  DATA lv_band TYPE c.

  " 1) Validaciones/armado de datos (tus performs existentes)
  PERFORM f_valida_registros.
  PERFORM f_valid_pago_comp CHANGING lv_band.
  IF lv_band = 'X'.
    RETURN.
  ENDIF.

  " 2) ¿Hay datos? si no, volver a selección (no terminar programa)
  IF t_zta1_2 IS INITIAL.
    MESSAGE TEXT-004 TYPE 'I'.     " No hay información para mostrar
    LEAVE TO SCREEN 1000.
    RETURN.
  ENDIF.

  " 3) Mostrar ALV con status de emisión
  SORT t_zta1_2 BY bukrs kunnr ztpago anio_pago ztfactrel anio_fac.

  gv_ui_state = 'ALV'.
  PERFORM f_alv_el USING 'F_STAT_GUI_EMITIR'.

  " 4) Si el usuario cerró el ALV con Back/Exit, marcar bandera para que
  "    START-OF-SELECTION regrese a la selección sin re-ejecutar
  IF gv_alv_user_exit = abap_true.
    gv_back_from_alv = abap_true.
  ENDIF.

  gv_ui_state = 'SELSCR'.

ENDFORM.
