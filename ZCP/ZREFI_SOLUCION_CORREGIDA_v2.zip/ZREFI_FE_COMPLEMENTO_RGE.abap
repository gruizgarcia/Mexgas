*====================================================================*
*  INCLUDE: ZREFI_FE_COMPLEMENTO_RGE  (CORREGIDO)
*  - PF-STATUS: GUI_EMITIR / GUI_LOG
*  - ALV REUSE LVC con DATA_CHANGED y USER_COMMAND
*  - Manejo de Back/Exit/Cancel para volver a parámetros sin re-ejecutar
*====================================================================*

*--- Constante local: nombre de campo LVC para SELECCION (evita error de tipos)
CONSTANTS c_fname_seleccion TYPE lvc_fname VALUE 'SELECCION'.

*---------------------------------------------------------------------*
*      Form  F_CATALOGO_EMITIR_LVC
*---------------------------------------------------------------------*
FORM f_catalogo_emitir_lvc CHANGING ct_fcat TYPE lvc_t_fcat.

  DATA ls TYPE lvc_s_fcat.

  CLEAR ct_fcat.

  " Construcción base desde estructura ZSA1_CP1 (ajusta si difiere)
  CALL FUNCTION 'LVC_FIELDCATALOG_MERGE'
    EXPORTING
      i_structure_name = 'ZSA1_CP1'
    CHANGING
      ct_fieldcat      = ct_fcat.

  LOOP AT ct_fcat INTO ls.

    " Checkbox editable
    IF ls-fieldname = c_fname_seleccion.
      ls-checkbox  = 'X'.
      ls-edit      = 'X'.
      ls-outputlen = 1.
      ls-scrtext_s = 'Sel.'.
      ls-scrtext_m = 'Sel.'.
      ls-scrtext_l = 'Seleccion'.
      MODIFY ct_fcat FROM ls.
      CONTINUE.
    ENDIF.

    " Textos de columnas conocidas
    CASE ls-fieldname.
      WHEN 'UUID_FAC'.  ls-scrtext_l = 'UUID Factura'.      ls-scrtext_m = ls-scrtext_l. ls-scrtext_s = 'UUID FAC'.
      WHEN 'UUID_COMP'. ls-scrtext_l = 'UUID Complemento'.  ls-scrtext_m = ls-scrtext_l. ls-scrtext_s = 'UUID CP'.
      WHEN 'RFC_ORD'.   ls-scrtext_l = 'RFC Ordenante'.     ls-scrtext_m = ls-scrtext_l. ls-scrtext_s = 'RFC ORD'.
      WHEN 'RFC_BEN'.   ls-scrtext_l = 'RFC Beneficiario'.  ls-scrtext_m = ls-scrtext_l. ls-scrtext_s = 'RFC BEN'.
      WHEN 'ANIO_PAGO'. ls-scrtext_l = 'Año Pago'.
      WHEN 'ANIO_FAC'.  ls-scrtext_l = 'Año Factura'.
      WHEN 'NUMCOMP'.   ls-scrtext_l = 'Complemento#'.
    ENDCASE.

    " Ocultar columnas no deseadas (ajusta a tu necesidad)
    IF ls-fieldname = 'TIPO_CADPAGO'
    OR ls-fieldname = 'CERT_PAGO'
    OR ls-fieldname = 'NO_CERT'
    OR ls-fieldname = 'CAD_PAGO'
    OR ls-fieldname = 'SELLO_PAG'
    OR ls-fieldname = 'SERIE'
    OR ls-fieldname = 'RUTA_XML'
    OR ls-fieldname = 'RUTA_PDF'
    OR ls-fieldname = 'NUM_PAR'.
      ls-no_out = 'X'.
    ENDIF.

    MODIFY ct_fcat FROM ls.
  ENDLOOP.

ENDFORM.

*---------------------------------------------------------------------*
*      Form  F_EVENTOS
*---------------------------------------------------------------------*
FORM f_eventos  USING lt_events TYPE slis_t_event.
  DATA: l_event TYPE slis_alv_event.

  REFRESH lt_events.

  CALL FUNCTION 'REUSE_ALV_EVENTS_GET'
    EXPORTING
      i_list_type = 0
    IMPORTING
      et_events   = lt_events.

  " Vincular DATA_CHANGED (toggle de SELECCION y validaciones)
  l_event-name = 'DATA_CHANGED'.
  l_event-form = 'DATA_CHANGED'.
  APPEND l_event TO lt_events.
ENDFORM.

*---------------------------------------------------------------------*
*      Form  F_ALV_EL
*---------------------------------------------------------------------*
FORM f_alv_el  USING  lv_stat_gui TYPE slis_formname.

  DATA: lt_fcat TYPE lvc_t_fcat.
  DATA: ls_layo TYPE lvc_s_layo.
  DATA: lt_events TYPE slis_t_event.

  CLEAR ls_layo.
  ls_layo-zebra      = 'X'.
  ls_layo-cwidth_opt = 'X'.
  ls_layo-edit       = 'X'.  "para permitir edición del checkbox

  PERFORM f_catalogo_emitir_lvc CHANGING lt_fcat.
  PERFORM f_eventos USING lt_events.

  CLEAR gv_alv_user_exit.

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY_LVC'
    EXPORTING
      i_callback_program        = sy-repid
      i_callback_pf_status_set  = lv_stat_gui         "ej. 'F_STAT_GUI_EMITIR'
      i_callback_user_command   = 'F_USER_COMMAND'
      i_callback_data_changed   = 'DATA_CHANGED'
      is_layout_lvc             = ls_layo
      it_fieldcat_lvc           = lt_fcat
      it_excluding              = t_excluding
      it_events                 = lt_events
    TABLES
      t_outtab                  = t_zta1_2
    EXCEPTIONS
      program_error             = 1
      OTHERS                    = 2.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.

  IF gv_alv_user_exit = abap_true.
    RETURN.
  ENDIF.

ENDFORM.

*---------------------------------------------------------------------*
*      Form  F_STAT_GUI_EMITIR
*---------------------------------------------------------------------*
FORM f_stat_gui_emitir  USING rt_extab TYPE slis_t_extab.
  SET PF-STATUS 'GUI_EMITIR' EXCLUDING t_excluding.
ENDFORM.

*---------------------------------------------------------------------*
*      Form  F_USER_COMMAND
*---------------------------------------------------------------------*
FORM f_user_command USING r_ucomm     LIKE sy-ucomm
                           rs_selfield TYPE slis_selfield .

  DATA: lwa_zta1_2   TYPE zsa1_cp1.
  DATA: lv_fname     TYPE string.
  DATA: lv_col_start TYPE i.
  DATA: lv_row_start TYPE i.
  DATA: lv_col_end   TYPE i.
  DATA: lv_row_end   TYPE i.
  DATA: ls_tvarvc    TYPE tvarvc.
  DATA: lv_get_motcan TYPE string,
        lv_get_uuid   TYPE string.

  CONSTANTS: lc_verif(5)    TYPE c VALUE 'VERIF',
             lc_emitir(6)   TYPE c VALUE 'EMIT',
             lc_visxml(7)   TYPE c VALUE 'VIS_XML',
             lc_vispdf(7)   TYPE c VALUE 'VIS_PDF',
             lc_select(6)   TYPE c VALUE 'SELECT',
             lc_noselect(8) TYPE c VALUE 'NOSELECT',
             lc_recal(5)    TYPE c VALUE 'RECAL',
             lc_cancel(6)   TYPE c VALUE 'CANCEL'.

  rs_selfield-refresh    = 'X'.
  rs_selfield-col_stable = 'X'.
  rs_selfield-row_stable = 'X'.

  " Salidas estándar ALV
  IF r_ucomm = '&F03' OR r_ucomm = '&F12' OR r_ucomm = '&F15'
   OR r_ucomm = 'BACK' OR r_ucomm = 'EXIT' OR r_ucomm = 'CANC'.
    gv_alv_user_exit = abap_true.
    rs_selfield-exit = 'X'.
    CLEAR r_ucomm.
    RETURN.
  ENDIF.

  CASE r_ucomm.

    WHEN lc_select.
      LOOP AT t_zta1_2 INTO lwa_zta1_2 WHERE estatus NE c_rojo.
        lwa_zta1_2-seleccion = 'X'.
        MODIFY t_zta1_2 FROM lwa_zta1_2.
      ENDLOOP.

    WHEN lc_noselect.
      LOOP AT t_zta1_2 INTO lwa_zta1_2 WHERE estatus NE c_rojo.
        CLEAR lwa_zta1_2-seleccion.
        MODIFY t_zta1_2 FROM lwa_zta1_2.
      ENDLOOP.

    WHEN lc_verif.
      PERFORM f_verificar.

    WHEN lc_emitir.
      " opcional: validar selección aquí si quieres
      PERFORM f_emitir_boton.

    WHEN lc_visxml.
      IF rs_selfield-tabindex IS INITIAL.
        MESSAGE 'Seleccione un registro en el ALV.' TYPE 'I'.
        RETURN.
      ENDIF.
      READ TABLE t_zta1_2 INTO lwa_zta1_2 INDEX rs_selfield-tabindex.
      IF sy-subrc = 0.
        lv_fname = lwa_zta1_2-ruta_xml.
        PERFORM get_file_timbrado_sat USING 'VIS_XML' lwa_zta1_2-numcomp.
      ENDIF.

    WHEN lc_vispdf.
      IF rs_selfield-tabindex IS INITIAL.
        MESSAGE 'Seleccione un registro en el ALV.' TYPE 'I'.
        RETURN.
      ENDIF.
      READ TABLE t_zta1_2 INTO lwa_zta1_2 INDEX rs_selfield-tabindex.
      IF sy-subrc = 0.
        PERFORM f_visualiza_pdf_temp USING lwa_zta1_2 lwa_zta1_2-ruta_pdf.
      ENDIF.

    WHEN lc_cancel.
      IF rs_selfield-tabindex IS INITIAL.
        MESSAGE 'Seleccione un registro en el ALV.' TYPE 'I'.
        RETURN.
      ENDIF.

      READ TABLE t_zta1_2 INTO lwa_zta1_2 INDEX rs_selfield-tabindex.
      IF sy-subrc <> 0.
        MESSAGE 'No se pudo leer el registro seleccionado' TYPE 'E'.
        RETURN.
      ENDIF.

      CLEAR: gv_categoria, gv_comentario.

      " Coordenadas del popup
      SELECT SINGLE low INTO ls_tvarvc-low FROM tvarvc WHERE name = 'Z_POPUP_COL_START'.
      lv_col_start = ls_tvarvc-low.
      SELECT SINGLE low INTO ls_tvarvc-low FROM tvarvc WHERE name = 'Z_POPUP_ROW_START'.
      lv_row_start = ls_tvarvc-low.
      SELECT SINGLE low INTO ls_tvarvc-low FROM tvarvc WHERE name = 'Z_POPUP_COL_END'.
      lv_col_end   = ls_tvarvc-low.
      SELECT SINGLE low INTO ls_tvarvc-low FROM tvarvc WHERE name = 'Z_POPUP_ROW_END'.
      lv_row_end   = ls_tvarvc-low.

      IF lv_col_start IS INITIAL OR lv_row_start IS INITIAL
      OR lv_col_end   IS INITIAL OR lv_row_end   IS INITIAL.
        MESSAGE 'No se pudieron leer las coordenadas del popup (TVARVC).' TYPE 'E'.
        RETURN.
      ENDIF.

      CALL SCREEN 100 STARTING AT lv_col_start lv_row_start
                      ENDING   AT lv_col_end   lv_row_end.

      lv_get_motcan = gv_categoria.
      lv_get_uuid   = gv_comentario.

      IF lv_get_motcan <> '01'.
        PERFORM f_cancelar_uuid
          USING lwa_zta1_2-bukrs
                lwa_zta1_2-numcomp
                lwa_zta1_2-uuid_comp
                lv_get_motcan.
      ENDIF.

    WHEN lc_recal.
      CALL FUNCTION 'SAPGUI_PROGRESS_INDICATOR'
        EXPORTING percentage = 101 text = TEXT-001.

  ENDCASE.

ENDFORM.

*---------------------------------------------------------------------*
*      Form  DATA_CHANGED
*---------------------------------------------------------------------*
FORM data_changed  USING rr_data TYPE REF TO cl_alv_changed_data_protocol.

  DATA: lw_mod TYPE lvc_s_modi.
  FIELD-SYMBOLS: <row> TYPE zsa1_cp1.

  LOOP AT rr_data->mt_mod_cells INTO lw_mod.

    " Toggle de la casilla SELECCION
    IF lw_mod-fieldname = c_fname_seleccion.
      ASSIGN t_zta1_2[ lw_mod-row_id ] TO <row>.
      IF sy-subrc = 0.
        IF lw_mod-value = 'X' OR lw_mod-value = '1'.
          <row>-seleccion = 'X'.
        ELSE.
          CLEAR <row>-seleccion.
        ENDIF.
        rr_data->modify_cell(
          i_row_id    = lw_mod-row_id
          i_fieldname = c_fname_seleccion
          i_value     = <row>-seleccion ).
      ENDIF.
      CONTINUE.
    ENDIF.

    " ... (si tienes más validaciones de celdas, agrégalas aquí) ...

  ENDLOOP.

ENDFORM.
