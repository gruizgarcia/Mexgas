*&---------------------------------------------------------------------*
*& Report  ZREFI_FE_COMPLEMENTO
*&---------------------------------------------------------------------*
REPORT zrefi_fe_complemento.

TABLES sscrfields.

*=== Banderas/estado de UI ===
DATA: gv_alv_user_exit TYPE abap_bool VALUE abap_false,
      gv_back_from_alv TYPE abap_bool VALUE abap_false,
      gv_cancel        TYPE abap_bool VALUE abap_false,
      gv_current_pf    TYPE sypfkey,        " nombre del PF-STATUS activo
      gv_ui_state      TYPE c LENGTH 8 VALUE 'SELSCR'.  " SELSCR|ALV

*=== Variables ya usadas en tus includes ===
DATA gv_habilitar_campos TYPE abap_bool.

*=== Includes tuyos (declaraciones / negocio) ===
INCLUDE zrefi_fe_complemento_01. " Declaraciones (tipos, constants, tablas internas...)
INCLUDE zrefi_fe_complemento_02. " Rutinas (negocio)

*=== Includes corregidos (ALV + verificación) ===
INCLUDE zrefi_fe_complemento_rge.          " (en este zip)
INCLUDE zrefi_fe_complemento_logica_v4.    " (en este zip)

*=== Otros includes que ya usabas ===
INCLUDE zrefi_fe_complemento_statuso01.
INCLUDE zrefi_fe_complemento_user_ci01.
INCLUDE zrefi_fe_complemento_popup.
INCLUDE zrefi_fe_complemento_logica.

*======================================================================*
* Selection-Screen: no salir por Variantes; sólo actuar en F8
*======================================================================*
AT SELECTION-SCREEN ON EXIT-COMMAND.
  CASE sscrfields-ucomm.
    WHEN 'BACK' OR 'EXIT' OR 'CANC'.
      LEAVE PROGRAM.          " salir explícito si el usuario lo pide
    WHEN OTHERS.
      RETURN.                 " variantes, F4, etc. NO matan el programa
  ENDCASE.

AT SELECTION-SCREEN.
  IF sscrfields-ucomm <> 'ONLI'.
    RETURN.                   " solo F8 continúa
  ENDIF.
  PERFORM f_botones.          " tu perform existente para preparar botones

*======================================================================*
* Start-of-selection: flujo controlado (sin emitir aquí)
*======================================================================*
START-OF-SELECTION.

  IF sy-batch = 'X'.
    " En background puedes mantener tu flujo batch
    PERFORM f_verif.
    PERFORM f_verificar.      " si en batch abrevia ALV/validación
    PERFORM f_emitir.         " batch: emitir directo si aplica
    RETURN.
  ENDIF.

  " Limpiar banderas de sesión
  CLEAR: gv_alv_user_exit, gv_back_from_alv, gv_cancel.
  gv_ui_state = 'SELSCR'.

  " 1) Precarga ligera (no dispara emisión)
  PERFORM f_verif.

  " 2) Verificar + (posible) ALV en GUI_EMITIR
  PERFORM f_verificar.

  " 3) Si el usuario salió del ALV con Back/Exit/Cancel,
  "    regresar a la pantalla de parámetros (1000) y NO re-entrar
  IF gv_alv_user_exit = abap_true OR gv_back_from_alv = abap_true.
    CLEAR: gv_alv_user_exit, gv_back_from_alv.
    gv_ui_state = 'SELSCR'.
    LEAVE TO SCREEN 1000.   " vuelve a la selección
    RETURN.
  ENDIF.

  " 4) IMPORTANTE: NO llamar f_emitir_boton aquí.
  "    La emisión se ejecuta únicamente desde el ALV (botón EMIT).
